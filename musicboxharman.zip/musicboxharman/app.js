class App {

  constructor(menubar, musicbar) {
  	this.menu = menubar;
  	this.music = musicbar;

  	document.addEventListener('buttonClicked', this.buttonClickedListener); // add this listener

  }

  
  buttonClickedListener (event) {
  	app.music.theme = event.detail.chosenTheme;
  	app.music.song = event.detail.choice;

  	let url = "http://api.giphy.com/v1/gifs/search?q=" + event.detail.chosenTheme + "&api_key=dc6zaTOxFJmzC&limit=25&rating=g";

  	app.music.gif = new GifDisplay(url);
  }

}
