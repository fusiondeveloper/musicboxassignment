class PlayButton {
  constructor() {
    this.container = document.querySelector("#button");
    this.toggleEvent = this.toggleEvent.bind(this);
    this.isMusicPlaying = true;

    this.container.addEventListener('click', this.toggleEvent);
  }


// this is the stop button toggler. Checks whether the music should continue to play or not
  toggleEvent(event) {
    if (this.isMusicPlaying) { // check if the music is actually playing
      this.pause();
    }
    else { // if not
      this.play();
    }
    this.isMusicPlaying = !this.isMusicPlaying;
  }

  pause() {
    this.container.style.backgroundImage = "url(images/play.png)";
    app.music.aud.pause();
  }

  play() {
    this.container.style.backgroundImage = "url(images/pause.png)";
    app.music.aud.play();
  }

}
