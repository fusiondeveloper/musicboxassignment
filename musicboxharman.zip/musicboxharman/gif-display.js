class GifDisplay {
  constructor(url) {
    this.onStateReponse = this.onStateReponse.bind(this);
     this.changeGif = this.changeGif.bind(this);
	   this.jsonReadyState = this.jsonReadyState.bind(this);

	      this.urls = [];
	       this.index = 0;
	        this.nextGif = document.createElement('img');

	         fetch(url).then(this.onStateReponse).then(this.jsonReadyState);

  }

  jsonReadyState (json) {
  	for (const result of json.data) {
       this.urls.push(result.images.downsized.url);
    }

  	this.index = Math.floor(Math.random() * this.urls.length);
    this.newGif(true);
    this.newGif(false);
   }

  onStateReponse(response) {
  	return response.json();
  }


   newGif (firstState) {
   	 let displayContainArea = document.getElementById('displayArea');

   	 let musicImagePic = document.createElement('img');
	   musicImagePic.style.height = '50vw';

   	 musicImagePic.src = this.urls[this.index];
   	 musicImagePic.classList.add('image');

   	if (firstState) {
   		this.nextGif = musicImagePic;
   	} else {
   		displayContainArea.appendChild(musicImagePic);
   	}

   }


  changeGif () {
	   let displayContainerArea = document.getElementById('displayArea');


  	let randInt= Math.floor(Math.random() * this.urls.length);
  	while (this.index === randInt) {
  		randInt = Math.floor(Math.random() * this.urls.length);
  	}

  	let pic = document.createElement('img');
    	pic.src = this.urls[randInt];
    pic.style.height = '50vw';

    pic.classList.add('image');
    displayContainerArea.innerHTML = "";



  	displayContainerArea.appendChild(this.nextGif);

    this.nextGif = pic;

  }

}
