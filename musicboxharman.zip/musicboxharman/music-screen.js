class MusicScreen {

  constructor(containerElement) {
  	this.containerElement = containerElement;
    this.song;
  	this.gif;


  	this.theme;

  	this.url;
    this.aud = new AudioPlayer();
    let player = new PlayButton();

  }

  // hide and show functions go below here

  show () {
  	this.containerElement.classList.remove('inactive');
  	for (const keyVal in songs) {
  		if (songs[keyVal]['title'] === this.song) {
				this.url = songs[keyVal]['songUrl'];
 			}
 		}
    this.aud.setSong(this.url);
  }

  hide() {
  	this.containerElement.classList.add('inactive');
  }
}
